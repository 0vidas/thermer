package PatoLoko;

public class MallardDuck extends Duck{
	
	public void display() {
		System.out.println("I am the Sr.Mallard Duck");
	}

	
}
