package PatoLoko;

public class WoodDuck {

	public void quack() {
		System.out.println("...");
	}
	
	public void swim() {
		 System.out.println("Floating and getting wet");
	}
	
	public void fly() {
		System.out.println("I can't fly, please don't try it!");
	}
	
	public void display() {
		System.out.println("I'm a big and hard duck, hehe, made from wood");
	}
	
}
