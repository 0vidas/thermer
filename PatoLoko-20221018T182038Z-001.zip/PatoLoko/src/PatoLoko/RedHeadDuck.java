package PatoLoko;

public class RedHeadDuck extends Duck{

	public void display() {
		System.out.println("I'm a Red Head Duck");
	}

	
}
