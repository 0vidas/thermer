package PatoLoko;

public class Duck {

	
	public void quack() {
		System.out.println("Quack");
	}
	
	public void swim() {
		 System.out.println("Swiming chuplak chuplak");
	}
	
	public void fly() {
		System.out.println("Ducks can't fly!");
	}
	
	public void display() {
		System.out.println("I'm a fucking duck");
	}
	
}
